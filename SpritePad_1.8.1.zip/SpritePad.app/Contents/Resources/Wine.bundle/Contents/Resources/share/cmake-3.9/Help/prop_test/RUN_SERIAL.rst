RUN_SERIAL
----------

Do not run this test in parallel with any other test.

Use this option in conjunction with the ctest_test PARALLEL_LEVEL
option to specify that this test should not be run in parallel with
any other tests.
