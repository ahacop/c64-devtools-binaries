WORKING_DIRECTORY
-----------------

The directory from which the test executable will be called.

If this is not set it is called from the directory the test executable
is located in.
