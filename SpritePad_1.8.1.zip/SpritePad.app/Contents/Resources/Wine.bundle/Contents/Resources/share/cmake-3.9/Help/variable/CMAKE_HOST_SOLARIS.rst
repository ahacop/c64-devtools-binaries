CMAKE_HOST_SOLARIS
------------------

``True`` for Oracle Solaris operating systems.

Set to ``true`` when the host system is Oracle Solaris.
