CTEST_CUSTOM_PRE_TEST
----------------------

A list of commands to run at the start of the :command:`ctest_test` command.

.. include:: CTEST_CUSTOM_XXX.txt
