CMAKE_<LANG>_GHS_KERNEL_FLAGS_DEBUG
-----------------------------------

GHS kernel flags for ``Debug`` build type or configuration.

``<LANG>`` flags used when :variable:`CMAKE_BUILD_TYPE` is ``Debug``.
