#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/Users/mike/Documents/wine/usr/lib"
XSLT_LIBS="-lxslt -L/Users/mike/Documents/wine/src/libxml2-2.9.4 -L/Users/mike/Documents/wine/usr/lib -lxml2 -lz -lpthread -liconv -lm  "
XSLT_INCLUDEDIR="-I/Users/mike/Documents/wine/usr/include"
MODULE_VERSION="xslt-1.1.29"
