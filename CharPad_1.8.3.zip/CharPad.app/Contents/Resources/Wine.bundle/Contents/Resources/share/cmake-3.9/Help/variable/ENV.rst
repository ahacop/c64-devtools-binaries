ENV
---

Access environment variables.

Use the syntax ``$ENV{VAR}`` to read environment variable ``VAR``.  See also
the :command:`set` command to set ``ENV{VAR}``.
