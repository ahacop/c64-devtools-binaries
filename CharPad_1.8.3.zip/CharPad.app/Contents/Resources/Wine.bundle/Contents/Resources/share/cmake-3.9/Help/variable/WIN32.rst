WIN32
-----

``True`` on Windows systems, including Win64.

Set to ``true`` when the target system is Windows.
