CTEST_GIT_INIT_SUBMODULES
-------------------------

Specify the CTest ``GITInitSubmodules`` setting
in a :manual:`ctest(1)` dashboard client script.
