CMAKE_<LANG>_FLAGS_RELEASE
--------------------------

Flags for ``Release`` build type or configuration.

``<LANG>`` flags used when :variable:`CMAKE_BUILD_TYPE` is ``Release``.
