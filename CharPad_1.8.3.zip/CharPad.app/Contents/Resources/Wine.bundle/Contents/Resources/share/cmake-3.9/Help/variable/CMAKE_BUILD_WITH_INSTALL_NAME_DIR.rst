CMAKE_BUILD_WITH_INSTALL_NAME_DIR
---------------------------------

Whether to use :prop_tgt:`INSTALL_NAME_DIR` on targets in the build tree.

This variable is used to initialize the :prop_tgt:`BUILD_WITH_INSTALL_NAME_DIR`
property on all targets.
