
Armalyte Levels 4 and 7 are not featured because they don't use any character background.